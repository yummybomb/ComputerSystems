#ifndef QUICKSORT_H
#define QUICKSORT_H

#define ASCENDING true
#define DESCENDING false

void quickSort(int arr[], char *wordList[], int low, int high, int isAscending);

#endif
